./objects/timemanagement.o: Service\TimeManagement.c \
  Service\TimeManagement.h Pilotes\Timer_1234.h \
  C:\Users\aletr\AppData\Local\Arm\Packs\Keil\STM32F1xx_DFP\2.4.1\Device\Include\stm32f10x.h \
  RTE\_Cible_STlink_F103\RTE_Components.h \
  C:\Users\aletr\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\aletr\AppData\Local\Arm\Packs\Keil\STM32F1xx_DFP\2.4.1\Device\Include\system_stm32f10x.h
